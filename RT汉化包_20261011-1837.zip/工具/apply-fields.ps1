﻿param(
    [string]$mods = "",
    [string]$pairs = "",
    [string]$fields = "words",
    [string]$backupRoot = "",
    [string]$pathLike = "",
    [string]$csv = "",
    [string]$fileList = "",
    [switch]$IncludeModJson,
    [switch]$JsonValue,
    [switch]$DryRun
)
<#
  通用"就地改写 JSON 文本字段"工具

  用途: 游戏对部分字段不查 CSV, 直接显示 JSON 里的字符串, 必须就地替换。
  字段通过 -fields 指定(逗号分隔), 如: words,title,description

  对照表格式: 英文原文 <TAB> 中文译文 (UTF-8)
  保护: 已含中文的跳过; JSON 校验失败则跳过; 改前备份

  -JsonValue: 译文已是 JSON 转义形式(如从 Localization.json 的
  CULTURE_ZH_CN 提取的文本, 内含 \r\n 字面), 此时只转义双引号,
  不再做反斜杠翻倍与换行转义, 否则会写成 \\r\\n 而显示成字面反斜杠。
#>
$ErrorActionPreference = 'Stop'
$BS = [string][char]92
$packRoot = Split-Path $PSScriptRoot -Parent
if ([string]::IsNullOrWhiteSpace($mods)) {
    $gr = & (Join-Path $PSScriptRoot 'find-game.ps1')
    if ([string]::IsNullOrWhiteSpace($gr)) { Write-Host " 找不到游戏目录" -ForegroundColor Yellow; exit 1 }
    $mods = Join-Path $gr 'Mods'
}
if ([string]::IsNullOrWhiteSpace($backupRoot)) { $backupRoot = Join-Path $packRoot 'backup\Mods-fields' }
if (-not [IO.File]::Exists($pairs)) { Write-Host (" 找不到对照表: " + $pairs) -ForegroundColor Yellow; exit 1 }

$map = New-Object 'System.Collections.Generic.Dictionary[string,string]'
$csvMap = New-Object 'System.Collections.Generic.Dictionary[string,string]'
function CsvKey([string]$s) {
    $t = $s.ToLowerInvariant()
    $t = $t.Replace("`r`n", 'newline').Replace("`n", 'newline').Replace("`r", 'newline')
    $t = [regex]::Replace($t, '<[^>]*>', '')
    $t = $t.Replace(',', '^').Replace('.', '*')
    $t = [regex]::Replace($t, '["''`]', '')
    return [regex]::Replace($t, '\s+', '')
}
$sr = New-Object IO.StreamReader($pairs, [Text.Encoding]::UTF8)
while (-not $sr.EndOfStream) {
    $l = $sr.ReadLine()
    if ([string]::IsNullOrWhiteSpace($l)) { continue }
    $i = $l.IndexOf("`t"); if ($i -lt 1) { continue }
    $k = $l.Substring(0, $i); $v = $l.Substring($i + 1)
    if (-not $map.ContainsKey($k)) { $map[$k] = $v }
}
$sr.Close()
if (-not [string]::IsNullOrWhiteSpace($csv) -and [IO.File]::Exists($csv)) {
    foreach ($line in [IO.File]::ReadLines($csv, [Text.Encoding]::UTF8)) {
        $comma = $line.IndexOf(',')
        if ($comma -lt 1) { continue }
        $key = $line.Substring(0, $comma)
        if (-not $csvMap.ContainsKey($key)) { $csvMap[$key] = $line.Substring($comma + 1) }
    }
}
Write-Host ("对照表: " + $map.Count + " 条  字段: " + $fields)

# 构造字段正则: "(words|title|description)"\s*:\s*"..."
$fldAlt = ($fields -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) -join '|'
$rx = New-Object System.Text.RegularExpressions.Regex ('"(' + $fldAlt + ')"\s*:\s*"((?:[^"' + $BS + $BS + ']|' + $BS + $BS + '.)*)"')

function Unesc([string]$s) {
    return $s.Replace($BS + '/', '/').Replace($BS + '"', '"').Replace($BS + $BS, $BS)
}

$enc = New-Object Text.UTF8Encoding $false
$ser = $null
if (-not $DryRun) {
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer
    $ser.MaxJsonLength = [int]::MaxValue
}
$stats = @{ files = 0; changed = 0; repl = 0 }
$script:map = $map
$script:csvMap = $csvMap
$script:stats = $stats
$script:jsonValue = $JsonValue.IsPresent

$excl = @(
    ($BS + '.modtek' + $BS)
    'ModSaves'
)
$allFiles = if (-not [string]::IsNullOrWhiteSpace($fileList) -and [IO.File]::Exists($fileList)) {
    Get-Content -Encoding UTF8 $fileList | Where-Object { $_ } | ForEach-Object { [pscustomobject]@{ FullName = $_; Name = [IO.Path]::GetFileName($_); Extension = [IO.Path]::GetExtension($_) } }
} else { Get-ChildItem $mods -Recurse -File -Filter '*.json' }
$files = $allFiles | Where-Object {
    $p = $_.FullName; $bad = $false
    foreach ($e in $excl) { if ($p -like ('*' + $e + '*')) { $bad = $true } }
    # mod.json 默认跳过(多为元数据); -IncludeModJson 时放行(个别模组的
    # description 等字段是玩家可见的 mod 设置说明, 需要汉化)
    if (-not $IncludeModJson -and $_.Name -in @('mod.json', 'modstate.json')) { $bad = $true }
    # -pathLike 限定相对路径片段(逗号分隔, 任一匹配即处理)。
    # Name/Tooltip/Caption/Text 这类字段在别处可能是内部标识符或 ID,
    # 不能全局替换, 必须把处理范围压到具体文件。
    if (-not $bad -and $pathLike -ne '') {
        $rel = $p.Substring($mods.Length).TrimStart($BS)
        $hit = $false
        foreach ($pat in ($pathLike -split ',')) {
            $pat = $pat.Trim()
            if ($pat -ne '' -and $rel -like ('*' + $pat + '*')) { $hit = $true }
        }
        if (-not $hit) { $bad = $true }
    }
    -not $bad
}

foreach ($f in $files) {
    $stats.files++
    $orig = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)
    if ($orig -notmatch ('"(' + $fldAlt + ')"')) { continue }
    $new = $rx.Replace($orig, {
        param($m)
        $fld = $m.Groups[1].Value
        $val = Unesc $m.Groups[2].Value
        # JsonValue 词典中的 \n/\r 等本来就是 JSON 转义。旧版安装曾把
        # 反斜杠再次翻倍，导致游戏把换行显示成“\N”字样；这里先修正这类
        # 已含中文的字段，再执行常规英文查表。
        if ($script:jsonValue -and $m.Groups[2].Value -match '\\\\[nrt]' -and $val -match '\\[nrt]') {
            $e = $val.Replace('"', $BS + '"')
            $script:stats.repl++
            return '"' + $fld + '": "' + $e + '"'
        }
        if ($val -match '[\u4e00-\u9fff]') { return $m.Value }
        $zh = $null
        if ($script:map.ContainsKey($val)) { $zh = $script:map[$val] }
        if ($null -eq $zh -and $script:csvMap.Count -gt 0) {
            $ck = CsvKey $val
            if ($script:csvMap.ContainsKey($ck)) { $zh = $script:csvMap[$ck] }
        }
        if ($null -eq $zh) { return $m.Value }
        $script:stats.repl++
        if ($script:jsonValue) {
            # 译文已是 JSON 转义形式, 只需处理双引号(不能翻倍反斜杠,
            # 否则 \r\n 会变成 \\r\\n 在游戏里显示成字面反斜杠)
            $e = $zh.Replace('"', $BS + '"')
        } else {
            $e = $zh.Replace($BS, $BS + $BS).Replace('"', $BS + '"')
            $e = $e.Replace("`n", $BS + 'n').Replace("`r", $BS + 'r').Replace("`t", $BS + 't')
        }
        return '"' + $fld + '": "' + $e + '"'
    })
    if ($new -eq $orig) { continue }
    if (-not $DryRun) {
        try { [void]$ser.DeserializeObject($new) } catch { Write-Host ("跳过(JSON 无效): " + $f.Name); continue }
        $rel = $f.FullName.Substring($mods.Length).TrimStart($BS)
        $bak = Join-Path $backupRoot $rel
        $d = Split-Path $bak -Parent
        if (-not [IO.Directory]::Exists($d)) { [void][IO.Directory]::CreateDirectory($d) }
        if (-not [IO.File]::Exists($bak)) { [IO.File]::WriteAllText($bak, $orig, $enc) }
        [IO.File]::WriteAllText($f.FullName, $new, $enc)
    }
    $stats.changed++
}
Write-Host ("files=" + $stats.files + " changed=" + $stats.changed + " repl=" + $stats.repl)
